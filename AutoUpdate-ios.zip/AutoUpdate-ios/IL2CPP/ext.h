// Prevent multiple inclusion

// UnityEngine.Bounds minimal layout (center, extents)
struct Bounds {
    Vector3 m_Center;
    Vector3 m_Extents;
};




