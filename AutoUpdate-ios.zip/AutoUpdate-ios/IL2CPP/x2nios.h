//
//  Macros.h
//  ModMenu
//
//  Created by AHMED ALI on 4/2/19.
//  Copyright © 2019 Joey. All rights reserved.
//

#include <mach-o/dyld.h>
#include <dlfcn.h>